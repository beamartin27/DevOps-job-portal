#!/bin/bash

# Startup script for Azure App Service
echo "Starting application..."

# Install production dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
  echo "Installing production dependencies..."
  npm install --production --no-optional
fi

# Start the application
echo "Starting Node.js server..."
node server/index.js
